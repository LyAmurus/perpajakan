<?php

require_once "assets/konek.php";
$fname = $lname = $nik = $lahir = $email = $adress = $foto = "";
$fname_update = $lname_update = $nik_update = $lahir_update = $email_update = $adress_update = $foto_update = "";

if(isset($_POST["id"]) && !empty($_POST["id"])){
    $id = $_POST(["id"]);

    //mastiin diisi
    $input_fname = trim($_POST["fname"]);
    if(empty($input_fname)){
        $fname_update = "masukan nama depan.";
    } else{
        $fname = $input_fname;
    }
    $input_lname = trim($_POST["lname"]);
    if(empty($input_lname)){
        $lname_update = "masukan nama belakang.";
    } else{
        $lname = $input_lname;
    }
    $input_nik = trim($_POST["nik"]);
    if(empty($input_nik)){
        $nik_update = "masukan nik.";
    } else{
        $nik = $input_nik;
    }
    $input_lahir = trim($_POST["lahir"]);
    if(empty($input_lahir)){
        $lahir_update = "masukan tanggal lahir.";
    } else{
        $lahir = $input_lahir;
    }
    $input_email = trim($_POST["email"]);
    if(empty($input_email)){
        $email_update = "masukan email.";
    } else{
        $email = $input_email;
    }
    $input_adress = trim($_POST["adress"]);
    if(empty($input_adress)){
        $adress_update = "masukan alamat.";
    } else{
        $adress = $input_adress;
    }
    $input_foto = trim($_POST["foto"]);
    if(empty($input_foto)){
        $foto_update = "masukan foto.";
    } else{
        $foto = $input_foto;
    }

    //cek takut error
    if(empty($fname_update) && empty($lname_update) && empty($nik_update) && empty($lahir_update) && empty($email_update) && empty($adress_update) && empty($foto_update)){

        $sql="UPDATE user SET fname=?, lname=?, nik=?, lahir=?, email=?, adress=?, foto=? WHERE id=?";

        if($stmt = mysqli_prepare($conn, $sql)){
            mysqli_stmt_bind_param($stmt, "sssssssi", $param_fname, $param_lname, $param_nik, $param_lahir, $param_email, $param_adress, $param_foto, $param_id);

            $param_fname = $fname;
            $param_lname = $lname;
            $param_nik = $nik;
            $param_lahir = $lahir;
            $param_email = $email;
            $param_adress = $adress;
            $param_foto = $foto;
            $param_id = $id;

            if(mysqli_stmt_execute($stmt)){
                echo "dah bener cman belom ada profile";
            } else{
                echo "ada yang salah";
            }
        }
        mysqli_stmt_close($stmt);
    }
    mysqli_close($conn);
} else{
    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        $id = trim($_GET["id"]);

        $sql = "SELECT * FROM data_user WHERE id = ?";
        if($stmt = mysqli_prepare($conn, $sql)){
            mysqli_stmt_bind_param($stmt, "i", $param_id);

            $param_id = $id;

            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);

                if(mysqli_num_rows($result) == 1){
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

                    $fname = $row["fname"];
                    $lname = $row["lname"];
                    $nik = $row["nik"];
                    $lahir = $row["lahir"];
                    $email = $row["email"];
                    $adress = $row["adress"];
                    $foto = $row["foto"];
                } else{
                    echo "ada yang salah";
                }
            } else{
                echo "ada yang salah";
            }
        }
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
    } else{
        echo "ada yang salah";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
    <link rel="stylesheet" href="assets/settinguser/style.css">
    <link rel="stylesheet" href="assets/settinguser/responsive.css">
    <link rel="shortcut icon" href="assets/settinguser/users.svg" type="image/x-icon">

</head>

<body>
    <header>
        <div class="big-header">
            <div class="left">
                <div class="logo">
                    <h1>JakPajak</h1>
                </div>
                <div class="menu-Items">
                    <ul class="main-Ul dul-color">
                        <li>Home</li>
                    </ul>
                </div>
            </div>
            <div class="right">
                <div class="user-avtar">
                    <div class="imgg">
                        <img src="https://i.ibb.co/FKXL7gR/Whats-App-Image-2022-12-17-at-12-03-41.jpg" alt="">
                    </div>
                </div>
                <div class="button">
                    <button class="logout-btn">Logout</button>
                </div>
                <img src="https://i.ibb.co/FKXL7gR/Whats-App-Image-2022-12-17-at-12-03-41.jpg" class="menu-icon" alt="">
            </div>
        </div>
    </header>


    <section>
        <div class="acc-menu-open-dots">
            <img src="https://i.ibb.co/FKXL7gR/Whats-App-Image-2022-12-17-at-12-03-41.jpg" alt="" id="accMenuThreeDots">
        </div>
    </section>

    <section>
        <div class="account-Menu">
            <div class="account-Menu-sect-items">
                <button>Account</button>
                <button>Socail Profiles</button>
            </div>
        </div>
    </section>
    <section class="second-section">
        <div class="main-account-page-content">
            <div class="sec-right">
                <div class="sect-heading">
                    <h1>Settings Account</h1>
                </div>
                <div class="sect-items">
                    <p id="accountItem">Account</p>
                    <p id="logOutItem">LogOut</p>
                </div>
            </div>



<!-- Account Section -->
            <div class="sect-left" id="accountSection">
                <div class="dect-left-heading-1">
                    <h1>Account</h1>
                </div>
                <div class="sect-left-avatar-2">
                    <div class="sect-left-avatar-img">
                        <img src="https://i.ibb.co/FKXL7gR/Whats-App-Image-2022-12-17-at-12-03-41.jpg" alt="">
                    </div>
                    <div class="name-bio">
                        <p class="user-name" id="userNameAccount">
                            User
                        </p>
                        <p class="bio" id="UserBioAccount">
                            .
                        </p>
                    </div>
                </div>
                
                <div class="btns">
                    <button>Upload</button>
                </div>
                <hr size="1px" style="margin: 30px 0px 10px 0px;">

                <div class="account-edit-form-5">
                    <form action="a.js" class="acc-edit-frm">
                        <div class="form-1">
                            <div class="inner-form-1 <?php echo (!empty($fname_update)) ? 'ada-error' : ''; ?>">
                                <p>First Name</p>
                                <input type="text" name="fname" value="<?php echo $fname; ?>">
                                <span class="help-block"><?php echo $fname_update; ?></span>
                            </div>
                            <div class="inner-form-2 <?php echo (!empty($lname_update)) ? 'ada-error' : ''; ?>">
                                <p>Last Name</p>
                                <input type="text" name="lname" value="<?php echo $lname; ?>">
                                <span class="help-block"><?php echo $lname_update; ?></span>
                            </div>
                        </div>
                        <div class="form-2">
                            <div class="inner-form-2-1 <?php echo (!empty($nik_update)) ? 'ada-error' : ''; ?>">
                                <p>NIK</p>
                                <input type="text" name="nik" value="<?php echo $nik; ?>">
                                <span class="help-block"><?php echo $nik_update; ?></span>
                            </div>
                            <div class="inner-form-2-2 <?php echo (!empty($lahir_update)) ? 'ada-error' : ''; ?>">
                                <p>Tanggal Lahir</p>
                                <input type="text" name="lahir" value="<?php echo $lahir; ?>">
                                <span class="help-block"><?php echo $lahir_update; ?></span>
                                </div>
                            <div class="form-3 ">
                            <div class="inner-form-3-1 <?php echo (!empty($email_update)) ? 'ada-error' : ''; ?>">
                                <p>Email</p>
                                <input type="email" name="email" value="<?php echo $email; ?>">
                                <span class="help-block"><?php echo $email_update; ?></span>
                            </div>
                                <div class="inner-form-3-1 <?php echo (!empty($adress_update)) ? 'ada-error' : ''; ?>">
                                    <p>Address</p>
                                    <input type="Address" name="adress" value="<?php echo $adress; ?>">
                                    <span class="help-block"><?php echo $adress_update; ?></span>
                                </div>
                            </div>
                            <div class="save-btn">
                            <input type="hidden" name="id" value="<?php echo $id; ?>"/>
                            <input type="submit" class="save-bbtn" value="submit">
                            <a href="index.php" class="btn btn-default">Cancel</a>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="main-account-page-content-mobile" id="mobileAccMenuSection">
            <div class="sec-right-mobile">
                <div class="sect-heading-mobile">
                    <h1>Settings</h1>
                    <img src="https://i.ibb.co/FKXL7gR/Whats-App-Image-2022-12-17-at-12-03-41.jpg" alt="" id="accMenuCross">
                </div>
                <div class="sect-items-mobile">
                    <p id="accountItemMobile">Account</p>
                    <p id="logOutItemMobile">LogOut</p>
                </div>
            </div>
    </section>


</body>

</html>