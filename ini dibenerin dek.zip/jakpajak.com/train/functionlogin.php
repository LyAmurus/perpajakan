<?php

session_start();

include 'konek.php';

if(isset($_POST['submit'])){
    $username=$_POST['username'];
    $password=$_POST['password'];
    $result=mysqli_query($conn,"SELECT * FROM data_user WHERE username='".$username."' AND password='".$password."'");
    if(mysqli_num_rows($result)==1){
    $_SESSION['username']=$username;
    header("Location: profile.php");
    exit();
    }else{
    echo "Username atau Password salah";
    }
}







?>