<!DOCTYPE html>

<html>
<head>
    <link href="style.css" rel="stylesheet">
    <title>Log In | JakPajak</title>
    <body>
        <div class="loginbox">
            
            <h1>Log In</h1>
            <form action="functionlogin.php" method="post">
                <label>username</label>
                <input type="text" name= "username" placeholder="Email">
                <label>password</label>
                <input type="Password" name="password" placeholder="Password" required>
                <button type="submit" name="submit">login dek</button>
                <a href="#">Forget your Password?</a><br>
                <a href="#">Don't have account?</a>

            </form>
        </div>
    </body>
</head>

</html>