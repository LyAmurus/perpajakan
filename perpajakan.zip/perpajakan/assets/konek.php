<?php
$host = 'raaturuonly.my.id';
$db = 'raaturuo_perpajakan';
$usr = 'raaturuo_admin';
$pwd = 'kXS14f3yl9';

// parameter = hostname, username, password, database
$conn = mysqli_connect($host, $usr, $pwd, $db); //true|false

if (!$conn) {
    die("Gagal terhubung dengan database: " . mysqli_connect_error());
}